package com.ihsanmkls.githubuserapp2.api

import com.ihsanmkls.githubuserapp2.data.DetailUser
import com.ihsanmkls.githubuserapp2.data.UserResponse
import com.ihsanmkls.githubuserapp2.data.Users
import retrofit2.Call
import retrofit2.http.*

interface ApiServices {

    companion object {
        private const val API_TOKEN = "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"
    }

    @GET("search/users")
    @Headers("Authorization: token $API_TOKEN")
    fun getSearchUsers (
        @Query("q") query: String
    ) : Call<UserResponse>

    @GET("users/{username}")
    @Headers("Authorization: token $API_TOKEN")
    fun getUserDetail(
        @Path("username") username: String
    ): Call<DetailUser>

    @GET("users/{username}/followers")
    @Headers("Authorization: token $API_TOKEN")
    fun getUserFollowers(
        @Path("username") username: String
    ): Call<ArrayList<Users>>

    @GET("users/{username}/following")
    @Headers("Authorization: token $API_TOKEN")
    fun getUserFollowing(
        @Path("username") username: String
    ): Call<ArrayList<Users>>

}